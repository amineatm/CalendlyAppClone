INSERT INTO tag (name) VALUES ('coding');
INSERT INTO tag (name) VALUES ('javascript');
INSERT INTO tag (name) VALUES ('angular');
INSERT INTO tag (name) VALUES ('react');
INSERT INTO tag (name) VALUES ('mpp');
INSERT INTO tag (name) VALUES ('test');
INSERT INTO tag (name) VALUES ('java');