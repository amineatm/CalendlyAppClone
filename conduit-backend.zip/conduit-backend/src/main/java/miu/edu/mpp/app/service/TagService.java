package miu.edu.mpp.app.service;


import miu.edu.mpp.app.dto.tag.TagsResponse;

public interface TagService {
    TagsResponse getAllTags();
}